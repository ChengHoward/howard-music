Howard-music
============

Baidu.KuGou.KuWo.QQ.163.MiGu API

--------------

Installation
--------------

.. code:: console

    pip install h_music

More
--------------

https://github.com/tt20050510/howard-music