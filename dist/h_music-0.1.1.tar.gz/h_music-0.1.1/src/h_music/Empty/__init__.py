from .AlbumEmpty import Album
from .ResultEmpty import Result,ResultSearchMusic, ResultAlbum, ResultMusicInfo
from .SearchEmpty import SearchMusic
from .SingerEmpty import Singer
from .SongEmpty import Song
from .BaseEmpty import BaseEmpty
from .BaseAlbumEmpty import BaseAlbum
from .MusicInfoEmpty import MusicInfo
from .LyricEmpty import Lyric