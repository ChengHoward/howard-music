from .KuGou import KuGou
from .KuWo import KuWo
from .MiGu import MiGu
from .NetEase import NetEase
from .QianQian import QianQian
from .QQ import QQ