from .Site import KuGou
from .Site import KuWo
from .Site import MiGu
from .Site import NetEase
from .Site import QianQian
from .Site import QQ